//
//  ViewController.h
//  CompanyNameDB
//
//  Created by Clifton Gardner on 8/3/18.
//  Copyright © 2018 Clifton Gardner. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITextFieldDelegate>


@end

