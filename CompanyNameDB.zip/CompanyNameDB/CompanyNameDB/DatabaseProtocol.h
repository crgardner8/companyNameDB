//
//  DatabaseProtocol.h
//  CompanyNameDB
//
//  Created by Clifton Gardner on 8/8/18.
//  Copyright © 2018 Clifton Gardner. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>


@protocol DatabaseProtocol <NSObject>
@required
-(void)uploadData:(NSString *)dbData;
-(void)downloadDataForViewController:(UIViewController *)viewController;

@end
