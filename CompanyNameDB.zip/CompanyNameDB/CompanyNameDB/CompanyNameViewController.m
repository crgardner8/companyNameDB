//
//  CompanyNameViewController.m
//  CompanyNameDB
//
//  Created by Clifton Gardner on 8/9/18.
//  Copyright © 2018 Clifton Gardner. All rights reserved.
//

#import "CompanyNameViewController.h"

@interface CompanyNameViewController () 

@property (weak, nonatomic) IBOutlet UIView *overlayView;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;

@end

@implementation CompanyNameViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.navigationItem.title = @"Database";
    
    if (!self.companyNameList) {
        self.companyNameList = [NSArray new];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Public Methods

-(void)viewStartedLoading {
    
    self.overlayView.alpha = 0.85f;
    [self.activityIndicator startAnimating];
    
}

-(void)viewFinishedLoading {
    
    self.overlayView.alpha = 0.0f;
    [self.activityIndicator stopAnimating];
}

#pragma mark - Tableview Datasource and Delegate Methods

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.companyNameList.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *cellIdentifier = @"companyNameCellIdentifier";
    
    UITableViewCell *companyNameCell = [self.companyNameTableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (!companyNameCell) {
        
        companyNameCell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        companyNameCell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    companyNameCell.textLabel.text = self.companyNameList[indexPath.row];
    
    return companyNameCell;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
