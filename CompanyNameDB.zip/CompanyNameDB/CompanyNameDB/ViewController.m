//
//  ViewController.m
//  CompanyNameDB
//
//  Created by Clifton Gardner on 8/3/18.
//  Copyright © 2018 Clifton Gardner. All rights reserved.
//

#import "ViewController.h"
#import "CompanyNameViewController.h"

#import "FirebaseDB.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *companyName;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *saveCompany;

@property (strong, nonatomic) FirebaseDB *FBDatabase;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.navigationItem.title = @"Company Name";
    self.FBDatabase = [[FirebaseDB alloc] init];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - TextField Delegate Method

-(BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    [self saveButtonPressed:self.saveCompany];
    
    return YES;
}

#pragma mark - BarButton Methods

- (IBAction)saveButtonPressed:(UIBarButtonItem *)sender {
    
    if (self.companyName.text != nil && ![self.companyName.text isEqualToString:@""]) {
        [self.FBDatabase uploadData:self.companyName.text];
        self.companyName.text = @"";
        [self.companyName resignFirstResponder];
    }
}

- (IBAction)databaseButtonPressed:(UIBarButtonItem *)sender {
    
    CompanyNameViewController *companyNameVC = [self.storyboard instantiateViewControllerWithIdentifier:@"companyNameVC"];
    
    [companyNameVC viewStartedLoading];
    
    [self.FBDatabase downloadDataForViewController:companyNameVC];
    
    [self.navigationController pushViewController:companyNameVC animated:YES];
}


@end
