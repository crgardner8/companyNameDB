//
//  CompanyNameViewController.h
//  CompanyNameDB
//
//  Created by Clifton Gardner on 8/9/18.
//  Copyright © 2018 Clifton Gardner. All rights reserved.
//

#import "ViewController.h"

@interface CompanyNameViewController : ViewController <UITableViewDelegate, UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *companyNameTableView;
@property (strong, nonatomic) NSArray *companyNameList;

-(void)viewStartedLoading;
-(void)viewFinishedLoading;

@end
