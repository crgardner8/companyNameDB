//
//  FirebaseDB.m
//  CompanyNameDB
//
//  Created by Clifton Gardner on 8/8/18.
//  Copyright © 2018 Clifton Gardner. All rights reserved.
//

#import "FirebaseDB.h"
#import "CNDBConstants.h"

#import "CompanyNameViewController.h"

@import Firebase;

@interface FirebaseDB()

@property (strong, nonatomic) FIRDatabaseReference *ref;

@end

@implementation FirebaseDB

-(instancetype)init {
    self = [super init];
    
    if (self) {
        
        self.ref = [[FIRDatabase database] reference];
        self.database = [NSArray new];
    }
    
    return self;
}

-(void)uploadData:(NSString *)dbData {
    
    [[self.ref child:dbData] setValue:dbData];
}

-(void)downloadDataForViewController:(UIViewController *)viewController {
    
    if ([viewController isKindOfClass:[CompanyNameViewController class]]) {
        CompanyNameViewController *companyNameVC = (CompanyNameViewController *)viewController;
    
        [self.ref observeSingleEventOfType:FIRDataEventTypeValue withBlock:^(FIRDataSnapshot * _Nonnull snapshot) {
        
            if (snapshot.exists) {
            
                NSDictionary *companyDB = [[NSDictionary alloc] initWithDictionary:snapshot.value];
        
                companyNameVC.companyNameList = [NSArray arrayWithArray:companyDB.allValues];
            
            }
            
            dispatch_async(dispatch_get_main_queue(), ^{
                [companyNameVC.companyNameTableView reloadData];
                [companyNameVC viewFinishedLoading];
            });
        }];
    }
}

@end
