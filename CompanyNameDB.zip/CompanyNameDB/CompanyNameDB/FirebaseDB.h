//
//  FirebaseDB.h
//  CompanyNameDB
//
//  Created by Clifton Gardner on 8/8/18.
//  Copyright © 2018 Clifton Gardner. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DatabaseProtocol.h"

@interface FirebaseDB : NSObject<DatabaseProtocol>

@property (strong, nonatomic) NSArray *database;

@end
